^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package controller_stopper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.0 (2021-09-07)
------------------
* Initial release
* Contributors: Felix Exner, Felix Mauch, G.A. vd. Hoorn, Tristan Schnell
