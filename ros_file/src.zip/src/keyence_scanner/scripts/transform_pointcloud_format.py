#!/usr/bin/env python
import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
from sensor_msgs.msg import LaserScan
from laser_geometry import LaserProjection
from geometry_msgs.msg import PoseArray
from geometry_msgs.msg import Pose
from std_msgs.msg import Float32MultiArray
import numpy

class analysis():

    def __init__(self):
        rospy.init_node('analysis')
        self.poseArray = PoseArray() # Type: PoseArray
        self.pose = Pose()
        self.throttle = 0
        self.Floats = Float32MultiArray()
        self.laser_projector = LaserProjection()
        self.sub = rospy.Subscriber("cloud_out", PointCloud2, self.subcb, queue_size=10)
        self.time_old = rospy.get_time()
        self.pub = rospy.Publisher('point_cloud_data', PoseArray, queue_size=100)
        self.pub2 = rospy.Publisher('point_cloud_data2', Float32MultiArray, queue_size=10)
        rospy.spin()
        

    def subcb(self,cloud):
        if self.throttle%10 == 0:
            cloud_points = list(pc2.read_points(cloud, skip_nans=False, field_names = ("x", "y", "z")))
            
            #print("running")
            self.Floats.data = []
            for i in range(0,len(cloud_points)):
                #print(i[2])
                if numpy.isposinf(cloud_points[i][0]):
                    pass
                elif numpy.isneginf(cloud_points[i][0]):
                    pass
                else:
                    self.Floats.data.append(cloud_points[i][0])
                    self.Floats.data.append(cloud_points[i][1])
                    self.Floats.data.append(cloud_points[i][2])
                    
                    self.poseArray.poses.append(self.pose)


            self.pub2.publish(self.Floats)
            self.throttle = 1
        else:
            self.throttle += 1
        
        #cloud = self.laser_projector.projectLaser(scan)
        #gen = pc2.read_points(cloud, skip_nans=True, field_names=("x", "y", "z"))
        #self.xyz_generator = gen
        #)

if __name__ == '__main__':
    try:
        analysis()
    except rospy.ROSInterruptException:
        pass
