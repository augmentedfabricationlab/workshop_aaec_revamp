#!/usr/bin/env python

import rospy
import tf2_ros
import geometry_msgs.msg
import tf_conversions
from math import sin,cos,pi as Pi
from sensor_msgs.msg import JointState
from tf import transformations

from geometry_msgs.msg import PoseStamped
from tf2_sensor_msgs.tf2_sensor_msgs import do_transform_cloud
from sensor_msgs.msg import PointCloud2
from sensor_msgs.msg import PointCloud
from std_msgs.msg import Header
import tf
#import roslib; roslib.load_manifest('laser_assembler')


class keyence_transform():
    def __init__(self):
        rospy.init_node('keyence_transform_node')
        self.listener = tf.TransformListener() 
        rospy.sleep(1)
        now = rospy.Time.now()
        self.transform = geometry_msgs.msg.TransformStamped()
        #self.listener.waitForTransform("/base_link", "/sensor_optical_frame", now, rospy.Duration(4.0))
        rospy.Subscriber("/profiles",PointCloud2, self.pointcloud_cb)   
        rospy.Subscriber("/joint_states", JointState, self.joint_sate_callback)
        self.cloud_pub = rospy.Publisher("/cloud_out",PointCloud2, queue_size = 10)
        self.cloud_out = PointCloud2()
        rospy.loginfo("Transform publisher running")
        rospy.spin()
        

    def pointcloud_cb(self,cloud):


        self.transform.header.frame_id = "base_link"
        #self.transform.child_frame_id = "sensor_optical_frame"
        (trans,rot) = self.listener.lookupTransform('/base_link', '/sensor_optical_frame', rospy.Time(0))
        self.transform.transform.translation.x = trans[0]
        self.transform.transform.translation.y = trans[1]
        self.transform.transform.translation.z = trans[2]
        self.transform.transform.rotation.x = rot[0]
        self.transform.transform.rotation.y = rot[1]
        self.transform.transform.rotation.z = rot[2]
        self.transform.transform.rotation.w = rot[3]
        self.cloud_out = do_transform_cloud(cloud, self.transform)
        self.cloud_pub.publish(self.cloud_out)
        # #self.transform.header.stamp = rospy.Time.now()
        # self.transform.header.frame_id = "base_link"
        # # self.transform.child_frame_id = "sensor_optical_frame"
        # (trans,rot) = self.listener.lookupTransform('/base_link', '/sensor_optical_frame', rospy.Time(0))
        # print("TF",trans,rot)
        # self.transform.transform.translation.x = -self.DH1[3]
        # self.transform.transform.translation.y = -self.DH2[3]
        # self.transform.transform.translation.z = self.DH3[3]
        # R = transformations.rotation_matrix(0.0, (1, 2, 3))
        # R[0][0]=self.DH1[0]
        # R[0][1]=self.DH1[1]
        # R[0][2]=self.DH1[2]
        # R[1][0]=self.DH2[0]
        # R[1][1]=self.DH2[1]
        # R[1][2]=self.DH2[2]
        # R[2][0]=self.DH3[0]
        # R[2][1]=self.DH3[1]
        # R[2][2]=self.DH3[2]
        # quat = transformations.quaternion_from_matrix(R)
        # quat2 = [0.7071068, 0.7071068, 0, 0]
        # super_quat = transformations.quaternion_multiply(quat,quat2)
        # self.transform.transform.rotation.x = quat[0]
        # self.transform.transform.rotation.y = quat[1]
        # self.transform.transform.rotation.z = quat[2]
        # self.transform.transform.rotation.w = quat[3]
        # print(self.transform)
        # self.cloud_out = do_transform_cloud(cloud, self.transform)
        # self.cloud_pub.publish(self.cloud_out)

    def joint_sate_callback(self,joint_state):
        q1 = joint_state.position[2]
        q2 = joint_state.position[1]
        q3 = joint_state.position[0]
        q4 = joint_state.position[3] 
        q5 = joint_state.position[4]
        q6 = joint_state.position[5]

        self.DH1 = [  cos(q6)*(cos(q5)*(cos(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)) - sin(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2))) + sin(Pi/2)**2*sin(q1)*sin(q5)) - sin(Pi/2)*sin(q6)*(sin(Pi/2)*cos(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2)) + sin(Pi/2)*sin(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3))), - sin(q6)*(cos(q5)*(cos(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)) - sin(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2))) + sin(Pi/2)**2*sin(q1)*sin(q5)) - sin(Pi/2)*cos(q6)*(sin(Pi/2)*cos(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2)) + sin(Pi/2)*sin(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3))), sin(Pi/2)**3*cos(q5)*sin(q1) - sin(Pi/2)*sin(q5)*(cos(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)) - sin(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2))), (3483*sin(Pi/2)*sin(q1))/20000 - (6127*cos(q1)*cos(q2))/10000 + (2397*sin(Pi/2)*cos(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2)))/20000 + (2331*sin(Pi/2)**3*cos(q5)*sin(q1))/20000 + (2397*sin(Pi/2)*sin(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)))/20000 - (2331*sin(Pi/2)*sin(q5)*(cos(q4)*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)) - sin(q4)*(cos(q1)*cos(q2)*sin(q3) + cos(q1)*cos(q3)*sin(q2))))/20000 - (11431*cos(q1)*cos(q2)*cos(q3))/20000 + (11431*cos(q1)*sin(q2)*sin(q3))/20000]
        self.DH2 = [- cos(q6)*(cos(q5)*(cos(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)) + sin(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2))) + sin(Pi/2)**2*cos(q1)*sin(q5)) - sin(Pi/2)*sin(q6)*(sin(Pi/2)*cos(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2)) - sin(Pi/2)*sin(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1))),   sin(q6)*(cos(q5)*(cos(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)) + sin(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2))) + sin(Pi/2)**2*cos(q1)*sin(q5)) - sin(Pi/2)*cos(q6)*(sin(Pi/2)*cos(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2)) - sin(Pi/2)*sin(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1))), sin(Pi/2)*sin(q5)*(cos(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)) + sin(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2))) - sin(Pi/2)**3*cos(q1)*cos(q5), (11431*sin(q1)*sin(q2)*sin(q3))/20000 - (3483*sin(Pi/2)*cos(q1))/20000 - (6127*cos(q2)*sin(q1))/10000 - (2331*sin(Pi/2)**3*cos(q1)*cos(q5))/20000 + (2397*sin(Pi/2)*cos(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2)))/20000 - (2397*sin(Pi/2)*sin(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)))/20000 - (11431*cos(q2)*cos(q3)*sin(q1))/20000 + (2331*sin(Pi/2)*sin(q5)*(cos(q4)*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)) + sin(q4)*(cos(q2)*sin(q1)*sin(q3) + cos(q3)*sin(q1)*sin(q2))))/20000]
        self.DH3 = [                                                                                                                                                                                   sin(Pi/2)*sin(q2 + q3 + q4)*cos(q5)*cos(q6) - sin(Pi/2)*sin(q6)*(cos(Pi + q2 + q3 + q4)/4 - cos(q2 + q3 + q4)/2 + cos(Pi)/2 + cos(q2 - Pi + q3 + q4)/4 + 1/2),                                                                                                                                                                                   - sin(Pi/2)*cos(q6)*(cos(Pi + q2 + q3 + q4)/4 - cos(q2 + q3 + q4)/2 + cos(Pi)/2 + cos(q2 - Pi + q3 + q4)/4 + 1/2) - sin(Pi/2)*sin(q2 + q3 + q4)*cos(q5)*sin(q6),                                                                                                                                 sin(q2 + q3 + q4)*sin(q5)*(cos(Pi)/2 - 1/2),                                                                                                                                                                                                       (2397*cos(Pi))/40000 - (6127*sin(Pi/2)*sin(q2))/10000 - (11431*sin(Pi/2)*cos(q2)*sin(q3))/20000 - (11431*sin(Pi/2)*cos(q3)*sin(q2))/20000 + (2397*cos(q2 + q3)*cos(q4)*(cos(Pi)/2 - 1/2))/20000 - (2397*sin(q2 + q3)*sin(q4)*(cos(Pi)/2 - 1/2))/20000 + (2331*sin(q2 + q3 + q4)*sin(q5)*(cos(Pi)/2 - 1/2))/20000 + 77/320 ]
        self.DH4 = [                                                                                                                                                                                                                                                                                                                                                0,                                                                                                                                                                                                                                                                                                                                                 0,                                                                                                                                                                           0,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               1]
        
                
                





if __name__=="__main__":
    keyence_transform()
